// 云函数：检测内容安全
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

exports.main = async (event, context) => {
  const { content } = event;

  if (!content || content.trim() === '') {
    return {
      success: false,
      message: '内容不能为空'
    };
  }

  try {
    // 使用 v2 版本的内容安全接口
    const result = await cloud.openapi.security.msgSecCheck({
      openid: context.OPENID || 'test-openid',
      scene: 2, // 场景值：1-资料；2-评论；3-论坛；4-社交日志
      version: 2, // 使用 v2 版本
      content: content
    });

    console.log('内容安全检测结果:', result);

    // v2 版本返回格式：result.result.suggest
    // pass-通过，review-需人工审核，risky-违规
    const suggest = result.result?.suggest || 'pass';

    return {
      success: true,
      isSafe: suggest === 'pass',
      message: suggest === 'pass' ? '内容安全' : '内容包含敏感信息，请修改后重试'
    };

  } catch (err) {
    console.error('内容安全检测失败:', err);

    // errCode === 87014 表示内容违规
    if (err.errCode === 87014) {
      return {
        success: true,
        isSafe: false,
        message: '内容包含敏感信息，请修改后重试'
      };
    }

    // 其他错误
    return {
      success: false,
      message: err.errMsg || '检测失败，请重试'
    };
  }
};
